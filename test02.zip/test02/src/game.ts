import { getUserData } from "@decentraland/Identity"
import { getPlayerData } from "@decentraland/Players"

const box = new Entity()
box.addComponent(new CylinderShape)
box.addComponent(new Transform())
box.getComponent(Transform).position.set(2, 1, 2)
box.getComponent(Transform).scale.set(1, .1, 1)
engine.addEntity(box)
//cannot add another new shape and use same components from this entity.  must create new entity.

const box2 = new Entity()
box2.addComponent(new CylinderShape)
box2.addComponent(new Transform())
box2.getComponent(Transform).position.setAll(8)
box2.getComponent(Transform).scale.setAll(2) //don't add another "new transform()", you use the same transform component.
box2.getComponent(Transform).rotation.setEuler(90, 90, 90)
box2.addComponent(new Billboard(false, false, true))
engine.addEntity(box2)

const box3 = new Entity()
box3.addComponent(new CylinderShape)
box3.addComponent(new Transform())
box3.getComponent(Transform).position.set(3, 2, 3)
box3.getComponent(Transform).scale.set(1, .1, 1)
engine.addEntity(box3)

const box4 = new Entity()
box4.addComponent(new CylinderShape)
box4.addComponent(new Transform())
box4.getComponent(Transform).position.set(4, 3, 4)
box4.getComponent(Transform).scale.set(1, .1, 1)
engine.addEntity(box4)

const box5 = new Entity()
box5.addComponent(new CylinderShape)
box5.addComponent(new Transform())
box5.getComponent(Transform).position.set(5, 4, 5)
box5.getComponent(Transform).scale.set(1, .1, 1)
engine.addEntity(box5)

const box6 = new Entity()
box6.addComponent(new CylinderShape)
box6.addComponent(new Transform())
box6.getComponent(Transform).position.set(6, 5, 6)
box6.getComponent(Transform).scale.set(1, .1, 1)
engine.addEntity(box6)

const wall1 = new Entity()
wall1.addComponent(new BoxShape)
wall1.addComponent(new Transform())
wall1.getComponent(Transform).position.set(4, .5, 4)
wall1.getComponent(Transform).scale.set(8, .5, .5)
wall1.getComponent(Transform).lookAt(new Vector3(8, .5, 0))
engine.addEntity(wall1)

const wall2 = new Entity()
wall2.addComponent(new BoxShape)
wall2.addComponent(new Transform())
wall2.getComponent(Transform).position.set(12, .5, 4)
wall2.getComponent(Transform).scale.set(8, .5, .5)
wall2.getComponent(Transform).lookAt(new Vector3(8, .5, 0))
engine.addEntity(wall2)

const wall3 = new Entity()
wall3.addComponent(new BoxShape)
wall3.addComponent(new Transform())
wall3.getComponent(Transform).position.set(12, .5, 12)
wall3.getComponent(Transform).scale.set(8, .5, .5)
wall3.getComponent(Transform).lookAt(new Vector3(8, .5, 0))
engine.addEntity(wall3)

const wall4 = new Entity()
wall4.addComponent(new BoxShape)
wall4.addComponent(new Transform())
wall4.getComponent(Transform).position.set(4, .5, 12)
wall4.getComponent(Transform).scale.set(8, .5, .5)
wall4.getComponent(Transform).lookAt(new Vector3(8, .5, 0))
engine.addEntity(wall4)


const head = new Entity()
head.addComponentOrReplace(
    new AttachToAvatar({
        avatarId: '"jelloworld"',
        anchorPointId: AttachToAvatarAnchorPointId.NameTag,
    })
)
engine.addEntity(head)